# Задание 1
# Напишите программу, которая спрашивает у пользователя два слова и выводит их разделёнными запятой.

word1 = input("Input first word: ")
word2 = input("input second word: ")

print(word1, word2, sep=(","))